package paytm.test;

public class AvgTemp {
	private String COUNTRY_FULL;
	private Double TEMP;
	public String getCOUNTRY_FULL() {
		return COUNTRY_FULL;
	}
	public void setCOUNTRY_FULL(String cOUNTRY_FULL) {
		COUNTRY_FULL = cOUNTRY_FULL;
	}
	public Double getTEMP() {
		return TEMP;
	}
	public void setTEMP(Double tEMP) {
		TEMP = tEMP;
	}

}
