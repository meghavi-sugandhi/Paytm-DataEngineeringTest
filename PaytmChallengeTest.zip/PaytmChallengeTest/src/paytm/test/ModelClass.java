package paytm.test;

public class ModelClass {
	private String STN;
	private String WBAN;
	public String getSTN() {
		return STN;
	}
	public void setSTN(String sTN) {
		STN = sTN;
	}
	public String getWBAN() {
		return WBAN;
	}
	public void setWBAN(String wBAN) {
		WBAN = wBAN;
	}
	public String getYEARMODA() {
		return YEARMODA;
	}
	public void setYEARMODA(String yEARMODA) {
		YEARMODA = yEARMODA;
	}
	public Double getTEMP() {
		return TEMP;
	}
	public void setTEMP(Double tEMP) {
		TEMP = tEMP;
	}
	public String getDEWP() {
		return DEWP;
	}
	public void setDEWP(String dEWP) {
		DEWP = dEWP;
	}
	public String getSLP() {
		return SLP;
	}
	public void setSLP(String sLP) {
		SLP = sLP;
	}
	public String getSTP() {
		return STP;
	}
	public void setSTP(String sTP) {
		STP = sTP;
	}
	public String getVISIB() {
		return VISIB;
	}
	public void setVISIB(String vISIB) {
		VISIB = vISIB;
	}
	public Double getWDSP() {
		return WDSP;
	}
	public void setWDSP(Double wDSP) {
		WDSP = wDSP;
	}
	public String getMXSPD() {
		return MXSPD;
	}
	public void setMXSPD(String mXSPD) {
		MXSPD = mXSPD;
	}
	public String getGUST() {
		return GUST;
	}
	public void setGUST(String gUST) {
		GUST = gUST;
	}
	public String getMAX() {
		return MAX;
	}
	public void setMAX(String mAX) {
		MAX = mAX;
	}
	public String getMIN() {
		return MIN;
	}
	public void setMIN(String mIN) {
		MIN = mIN;
	}
	public String getPRCP() {
		return PRCP;
	}
	public void setPRCP(String pRCP) {
		PRCP = pRCP;
	}
	public String getSNDP() {
		return SNDP;
	}
	public void setSNDP(String sNDP) {
		SNDP = sNDP;
	}
	public String getFRSHTT() {
		return FRSHTT;
	}
	public void setFRSHTT(String fRSHTT) {
		FRSHTT = fRSHTT;
	}
	public String getSTN_NO() {
		return STN_NO;
	}
	public void setSTN_NO(String sTN_NO) {
		STN_NO = sTN_NO;
	}
	public String getCOUNTRY_ABBR() {
		return COUNTRY_ABBR;
	}
	public void setCOUNTRY_ABBR(String cOUNTRY_ABBR) {
		COUNTRY_ABBR = cOUNTRY_ABBR;
	}
	public String getCOUNTRY_ABBR1() {
		return COUNTRY_ABBR1;
	}
	public void setCOUNTRY_ABBR1(String cOUNTRY_ABBR1) {
		COUNTRY_ABBR1 = cOUNTRY_ABBR1;
	}
	public String getCOUNTRY_FULL() {
		return COUNTRY_FULL;
	}
	public void setCOUNTRY_FULL(String cOUNTRY_FULL) {
		COUNTRY_FULL = cOUNTRY_FULL;
	}
	private String YEARMODA;
	private Double TEMP;
	private String DEWP;  
	private String SLP;
	private String STP;
	private String VISIB;
	private Double WDSP;
	private String MXSPD;
	private String GUST;
	private String MAX;
	private String  MIN;
	private String PRCP;
	private String SNDP;
	private String FRSHTT;
	private String STN_NO;
	private String COUNTRY_ABBR;
	private String COUNTRY_ABBR1;
	private String COUNTRY_FULL;
	

}
